package com.example.demo.domain;

public class FileSaver {

    private String file;
    private String porvince;
    private String city;
    private String district;

    public String getPorvince() { return porvince; }
    public void setPorvince(String porvince) {
        this.porvince = porvince;
    }

    public String getCity() { return city; }
    public void setCity(String city) {
        this.city = city;
    }

    public String getDistrict() { return district; }
    public void setDistrict(String district) {
        this.district = district;
    }

//    public Object getMapFile() {
////      读取本地json文件
////      1.创建文件对象
//        File fromFile = new File("file/json/map.json");
////      2.创建字符输入流
//        Reader reader = null;
//        try {
//            reader = new FileReader(fromFile);
//            // 3.循环读取（打印）
//            int content = reader.read();
//            while (content != -1) {
//                content = reader.read();
////                System.out.print((char) content);
//                this.file = content;
//                System.out.print(this.file);
//            }
//            System.out.print((char) content);
//            return content;
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        } finally {
//            // 4.关闭流
//            try {
//                reader.close();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//        System.out.print(this.file);
//        return this.file;
//    }
}
