package com.example.demo.controller;

import com.example.demo.domain.FileSaver;
import org.springframework.core.io.ClassPathResource;

import java.io.File;
import java.io.FileReader;
import java.io.Reader;

public class FileSaverController {
//    System.out.println("########");
//    FileSaver file = new FileSaver();
//    file.println();
}
