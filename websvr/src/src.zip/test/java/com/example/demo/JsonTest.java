package com.example.demo;

// 这个本地的操作只能在test里面么？不调用接口不能用main？
//是的，不能掉main
import com.example.demo.service.JsonFileService;
import net.minidev.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.lang.reflect.Array;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class JsonTest {

    @Autowired
    private JsonFileService jsonFileService;

    @Test
    public void jsonTest(){
        String json = jsonFileService.getData();
        System.out.println("json:" + json);

//        JSONObject object = json.get();

    }



}
